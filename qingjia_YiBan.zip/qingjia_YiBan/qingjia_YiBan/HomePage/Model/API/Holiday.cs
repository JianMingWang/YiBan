﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace qingjia_YiBan.HomePage.Model.API
{
    public class Holiday
    {
        public string TeacherID { get; set; }
        public string DeadLine { get; set; }
    }
}