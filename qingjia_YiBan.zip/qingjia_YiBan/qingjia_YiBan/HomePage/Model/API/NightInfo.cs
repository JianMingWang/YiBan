﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace qingjia_YiBan.HomePage.Model.API
{
    public class NightInfo
    {
        public string TeacherID { get; set; }
        public string TeacherName { get; set; }
        public string BatchTime { get; set; }
        public string DeadLine { get; set; }
    }
}