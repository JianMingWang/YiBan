﻿using System;

namespace qingjia_YiBan.SubPage
{
    public partial class schoolleave_succeed : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}